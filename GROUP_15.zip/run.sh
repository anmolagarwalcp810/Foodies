python ./FRONT_END/main.py
