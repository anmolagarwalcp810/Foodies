pip install flask
pip install flask-wtf
pip install wtforms
pip install flask-bootstrap
pip install psycopg2
pip install matplotlib
